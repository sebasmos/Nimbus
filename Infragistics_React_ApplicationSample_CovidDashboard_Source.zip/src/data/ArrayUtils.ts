
export class Array {

    // public static remove(array: any[], obj: any): any[] {
    //     return array.filter((item, i, arr) => item !== obj);
    // }

    // public static contains(array: any[], obj: any): boolean {
    //     return array.indexOf(obj) >= 0;
    // }
}